// console.log("helloo ");
// console.log("adsadsaadadadadaddas")
// console.log("rishi")

import express from 'express'
const app = express()

const PORT = 4000

// get    ->  data bajna 
// post   ->  data lana 
// put    ->  update karna 
// delete ->  data delete karna

app.get('/',(req,res)=>{
    res.send('hello world rishi')
})

app.listen(PORT)